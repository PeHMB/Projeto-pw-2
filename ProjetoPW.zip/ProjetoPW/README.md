# Projeto Receitas Culinárias

## Integrantes

* Augusto Linhares
* Camila Ortolane
* Pedro Henrique
* Kewillem Nikoly

> Páginas obrigatórias
* Home
* Quem somos
* Doces
* Salgados
* Contato
* Localização
> Páginas Opcionais
* Minhas receitas
* Favoritos